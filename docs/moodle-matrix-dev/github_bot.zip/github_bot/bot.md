# Core: GithubBot (`bot.py`)

Ubicación: `maubot/github-bot-plugin/github_bot/bot.py`

El archivo `bot.py` coordina la interacción entre el usuario (vía Matrix), la base de conocimientos (vía GitHub) y el motor de estudio.

## Descripción General

```python
--8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:file_desc"
```

## Diagrama de Interacción de Mensajes

```mermaid
graph TD
    A["Mensaje entrante en Matrix"] --> B{"¿Es un adjunto?"}
    B -->|"Sí (Imagen / PDF)"| C["Proceso de Ingesta"]
    C --> D["OCR / PyPDF / Gemini Vision"]
    D --> E["Subir a GitHub raw/ y okf/"]
    B -->|"No"| F{"¿Es un comando ! ?"}
    F -->|"Sí"| G["Delegar a handlers estudio.py / bd.py"]
    F -->|"No"| H{"¿Hay estado pendiente?"}
    H -->|"Sí"| I["Responder a flashcard / Ejercicio"]
    H -->|"No"| J["Ignorar"]
```

## Ciclo de Vida y Concurrencia

El bot implementa un control de caché agresivo y manejo asíncrono avanzado con semáforos (`MAX_CONCURRENCIA_GITHUB`) para no exceder las cuotas de la API del proveedor (GitHub/GitLab) ni solapar transacciones concurrentes en el chat (`_user_locks`).

## Métodos de la Clase `GithubBot`

A continuación se documentan todos los métodos expuestos por el bot, junto con su código fuente correspondiente embebido directamente desde `bot.py`.

### `start`

Punto de entrada de Maubot. Inicializa el bot y la conexión a la base de datos.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:start"
    ```

### `_crear_llm`

Crea e inicializa la instancia del modelo de lenguaje.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_crear_llm"
    ```

### `_crear_llm_vision`

Crea e inicializa la instancia del modelo de lenguaje con capacidades de visión.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_crear_llm_vision"
    ```

### `_obtener_documentacion`

Obtiene la documentación o apuntes del repositorio Git.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_obtener_documentacion"
    ```

### `_recorrer_carpeta`

Recorre una carpeta del repositorio y lista sus archivos.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_recorrer_carpeta"
    ```

### `_descargar_contenido_fichero`

Descarga el contenido de un fichero específico del repositorio.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_descargar_contenido_fichero"
    ```

### `_listar_rutas`

Lista las rutas disponibles en el repositorio.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_listar_rutas"
    ```

### `_listar_carpetas`

Lista las carpetas disponibles en una ruta específica.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_listar_carpetas"
    ```

### `_recorrer_carpetas_dirs`

Recorre las carpetas para listar subdirectorios.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_recorrer_carpetas_dirs"
    ```

### `_recorrer_carpeta_con_sha`

Recorre una carpeta del repositorio incluyendo el hash SHA de los archivos.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_recorrer_carpeta_con_sha"
    ```

### `on_message`

Manejador principal de eventos de mensaje. Procesa todos los mensajes entrantes de la sala.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:on_message"
    ```

### `_encolar_para_lote`

Encola un archivo para ser procesado posteriormente en lote.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_encolar_para_lote"
    ```

### `_vista_previa_transcripcion`

Genera una vista previa de la transcripción de un documento.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_vista_previa_transcripcion"
    ```

### `_debounce_lote`

Implementa un mecanismo de debounce para el procesamiento por lotes.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_debounce_lote"
    ```

### `_procesar_respuesta_destino`

Procesa la respuesta del usuario sobre la carpeta de destino de un archivo.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_procesar_respuesta_destino"
    ```

### `_procesar_renombrado`

Procesa la respuesta del usuario para renombrar un archivo.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_procesar_renombrado"
    ```

### `_guardar_ficheros_en_carpeta`

Guarda múltiples archivos en una carpeta de destino.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_guardar_ficheros_en_carpeta"
    ```

### `_descargar_adjunto`

Descarga un archivo adjunto enviado a la sala de Matrix.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_descargar_adjunto"
    ```

### `_resolver_ruta_unica`

Resuelve la ruta única para guardar un archivo en el repositorio.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_resolver_ruta_unica"
    ```

### `_obtener_sha_y_contenido_github`

Obtiene el SHA y el contenido de un archivo en GitHub.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_obtener_sha_y_contenido_github"
    ```

### `_subir_o_actualizar_archivo_github`

Sube un archivo nuevo o actualiza uno existente en GitHub.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_subir_o_actualizar_archivo_github"
    ```

### `_append_log_okf`

Añade un registro al log de operaciones del formato OKF.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_append_log_okf"
    ```

### `_obtener_agents_md`

Obtiene el contenido del archivo de reglas AGENTS.md.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_obtener_agents_md"
    ```

### `_ejecutar_ingest_por_lotes`

Ejecuta el proceso de ingesta de archivos en lotes.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_ejecutar_ingest_por_lotes"
    ```

### `ingest_lotes_handler`

Comando para iniciar manualmente la ingesta por lotes.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:ingest_lotes_handler"
    ```

### `_borrar_archivo_github`

Elimina un archivo del repositorio de GitHub.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_borrar_archivo_github"
    ```

### `_mover_archivo_github`

Mueve un archivo a una nueva ruta dentro del repositorio de GitHub.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_mover_archivo_github"
    ```

### `_subir_archivo_github`

Sube un archivo al repositorio de GitHub.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_subir_archivo_github"
    ```

### `pregunta_handler`

Manejador del comando !pregunta para resolver dudas sobre los apuntes.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:pregunta_handler"
    ```

### `ficheros_handler`

Manejador del comando !ficheros para listar los archivos del repositorio.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:ficheros_handler"
    ```

### `estadisticas_handler`

Manejador del comando !estadisticas para mostrar estadísticas de estudio.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:estadisticas_handler"
    ```

### `trazabilidad_handler`

Manejador del comando de trazabilidad general.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:trazabilidad_handler"
    ```

### `trazabilidad_qa_handler`

Manejador del comando de trazabilidad de QA.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:trazabilidad_qa_handler"
    ```

### `trazabilidad_interacciones_handler`

Manejador del comando de trazabilidad de interacciones.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:trazabilidad_interacciones_handler"
    ```

### `trazabilidad_curacion_handler`

Manejador del comando de trazabilidad de curación.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:trazabilidad_curacion_handler"
    ```

### `trazabilidad_exportar_handler`

Manejador del comando para exportar datos de trazabilidad.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:trazabilidad_exportar_handler"
    ```

### `documento_handler`

Manejador del comando !documento para obtener información de un archivo.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:documento_handler"
    ```

### `borrar_handler`

Manejador del comando !borrar para eliminar un archivo.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:borrar_handler"
    ```

### `_procesar_confirmacion_borrado`

Procesa la confirmación del usuario para borrar un archivo.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_procesar_confirmacion_borrado"
    ```

### `_procesar_confirmacion_borrado_carpeta`

Procesa la confirmación del usuario para borrar una carpeta completa.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_procesar_confirmacion_borrado_carpeta"
    ```

### `mover_handler`

Manejador del comando !mover para cambiar la ubicación de un archivo.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:mover_handler"
    ```

### `carpeta_handler`

Manejador del comando !carpeta para gestionar carpetas.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:carpeta_handler"
    ```

### `carpeta_crear_handler`

Manejador del comando para crear una nueva carpeta.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:carpeta_crear_handler"
    ```

### `carpeta_listar_handler`

Manejador del comando para listar carpetas.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:carpeta_listar_handler"
    ```

### `carpeta_borrar_handler`

Manejador del comando para borrar una carpeta.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:carpeta_borrar_handler"
    ```

### `_plantear_pregunta`

Plantea una pregunta de estudio al usuario.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_plantear_pregunta"
    ```

### `_evaluar_pendiente`

Evalúa una respuesta pendiente de una pregunta anterior.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_evaluar_pendiente"
    ```

### `_avanzar_repaso_tema`

Avanza a la siguiente pregunta en el repaso de un tema.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_avanzar_repaso_tema"
    ```

### `flashcard_handler`

Manejador del comando !flashcard para practicar conceptos.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:flashcard_handler"
    ```

### `ejercicio_handler`

Manejador del comando !ejercicio para generar ejercicios prácticos.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:ejercicio_handler"
    ```

### `concepto_handler`

Manejador del comando !concepto para explicar un concepto específico.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:concepto_handler"
    ```

### `feynman_handler`

Manejador del comando !feynman para practicar la Técnica de Feynman.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:feynman_handler"
    ```

### `_plantear_pregunta_concepto`

Plantea una pregunta específica sobre un concepto.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:_plantear_pregunta_concepto"
    ```

### `repasartema_handler`

Manejador del comando !repasartema para estudiar un tema completo.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:repasartema_handler"
    ```

### `ejerciciostema_handler`

Manejador del comando !ejerciciostema para ejercicios de un tema.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:ejerciciostema_handler"
    ```

### `resumen_handler`

Manejador del comando !resumen para generar un resumen de los apuntes.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:resumen_handler"
    ```

### `mapa_handler`

Manejador del comando !mapa para generar un mapa conceptual.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:mapa_handler"
    ```

### `ayuda_handler`

Manejador del comando !ayuda para mostrar los comandos disponibles.

??? quote "Ver Código Fuente"
    ```python
    --8<-- "moodle-matrix-dev/maubot/github-bot-plugin/github_bot/bot.py:ayuda_handler"
    ```

